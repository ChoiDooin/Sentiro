# Base_page.py

import sys
import os
from datetime import datetime
import paho.mqtt.client as mqtt
import json

from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QSizePolicy, QButtonGroup, QStackedLayout 
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont

from gui_map_viewer_start_point_import import MapWidget
from shop_search_page import ShopSearchPage
from robot_destination_page import RobotDestinationPage
from constants import TOUCH_ON, GUIDE_COMPLETE

class Basepage(QWidget):
    def __init__(self, stacked_widget=None):
        super().__init__()
        self.floor_label = None
        self.stacked_widget = stacked_widget
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.local_client = mqtt.Client()
        self.global_client = mqtt.Client()
        self.first_page_click_enabled = False

        self.local_client.on_connect = self.on_local_connect
        self.local_client.on_message = self.on_local_message
        self.global_client.on_connect = self.on_global_connect
        self.global_client.on_message = self.on_global_message

        self.local_client.connect_async("192.168.59.99", 1883, 60)
        self.local_client.loop_start()
        self.global_client.connect_async("192.168.59.202", 1883, 60)
        self.global_client.loop_start()

        base = os.path.dirname(os.path.abspath(__file__))
        self.geojson_folder = os.path.join(base, "geojson")
        self.images_folder = os.path.join(base, "gui_images")
        self.selected_floor = "1F"

        self.initUI()

    def on_local_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print("[Local] 연결 성공")
            client.subscribe("user/detect")
        else:
            print(f"[Local] 연결 실패: {rc}")

    def on_local_message(self, client, userdata, msg):
        print(f"[Local] 메시지 수신: {msg.topic} → {msg.payload.decode()}")
        if msg.topic == "user/detect":
            payload = msg.payload.decode()
            if payload.lower() == "true":
                print("✅ 클릭 활성화됨")
                self.first_page_click_enabled = True
                self.first_page.start_click_timers()

    def on_global_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print("[Global] 연결 성공")
            client.subscribe("global/topic")
        else:
            print(f"[Global] 연결 실패: {rc}")

    def on_global_message(self, client, userdata, msg):
        print(f"[Global] 메시지 수신: {msg.topic} → {msg.payload.decode()}")

    def publish_local(self, topic, message):
        self.local_client.publish(topic, message)

    def publish_global(self, topic, message, qos=0, retain=False):
        self.global_client.publish(topic, message, qos=qos, retain=retain)

    def initUI(self):
        self.setStyleSheet("background-color: white;")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.showFullScreen()

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        center_layout = QHBoxLayout()
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(0)

        self.left_widget = QWidget()
        self.left_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.left_layout = QVBoxLayout()
        self.left_layout.setContentsMargins(20, 20, 0, 0)
        self.left_layout.setSpacing(10)
        self.left_widget.setLayout(self.left_layout)

        title = QLabel("층별 안내")
        title.setFont(QFont("Pretendard", 24, QFont.Weight.Bold))
        self.left_layout.addWidget(title)

        self.floor_label = QLabel(self.selected_floor)
        self.floor_label.setFont(QFont("Pretendard", 36))
        self.left_layout.addWidget(self.floor_label)

        self.map_container = QWidget()
        self.map_container.setLayout(QStackedLayout())
        self.map_container.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.left_layout.addWidget(self.map_container)

        self.showFloorContent()
        center_layout.addWidget(self.left_widget, 85)

        menu_panel = self.createRightMenu()
        menu_panel.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        center_layout.addWidget(menu_panel, 15)

        main_layout.addLayout(center_layout)
        self.setLayout(main_layout)

    def showFloorContent(self):
        self.floor_label.setText(self.selected_floor)

        stack = self.map_container.layout()
        while stack.count():
            w = stack.widget(0)
            stack.removeWidget(w)
            w.setParent(None)

        mw = MapWidget(self.geojson_folder, self.images_folder, floor_code=self.selected_floor)
        mw.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.map_widget = mw

        stack.addWidget(mw)
        stack.setCurrentWidget(mw)

    def createRightMenu(self):
        panel = QWidget()
        panel.setStyleSheet("background-color: #ece6cc;")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        row = QWidget()
        hbox = QHBoxLayout(row)
        hbox.setContentsMargins(10, 10, 10, 0)
        hbox.setSpacing(10)
        hbox.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.floor_button_group = QButtonGroup(self)
        for fl in ["1F","2F"]:
            btn = QPushButton(fl)
            btn.setCheckable(True)
            btn.setChecked(fl == self.selected_floor)
            btn.setStyleSheet(self.getFloorButtonStyle(btn.isChecked()))
            btn.clicked.connect(lambda _, f=fl, b=btn: self.changeFloor(f, b))
            self.floor_button_group.addButton(btn)
            hbox.addWidget(btn)
        layout.addWidget(row)

        header = QWidget()
        vhead = QVBoxLayout(header)
        vhead.setAlignment(Qt.AlignmentFlag.AlignCenter)

        mall = QLabel("HY\nMALL")
        mall.setFont(QFont("Pretendard", 36, QFont.Weight.Bold))
        mall.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vhead.addWidget(mall)

        self.date_label = QLabel()
        self.date_label.setFont(QFont("Pretendard", 14))
        self.date_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vhead.addWidget(self.date_label)

        self.time_label = QLabel()
        self.time_label.setFont(QFont("Pretendard", 16))
        self.time_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vhead.addWidget(self.time_label)

        weather = QLabel("🌤️ 19°C")
        weather.setFont(QFont("Pretendard", 14))
        weather.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vhead.addWidget(weather)

        layout.addWidget(header, 4)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.updateTime)
        self.timer.start(1000)
        self.updateTime()

        def createMenuButton(txt, handler):
            b = QPushButton(txt)
            b.setStyleSheet("""
                QPushButton {
                    background-color: #f5fdc;
                    font-size: 18px;
                    border: none;
                    border-radius: 8px;
                    margin: 5px;
                }
                QPushButton:hover { background-color: #ffffff; }
            """)
            b.clicked.connect(handler)
            b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            return b

        layout.addWidget(createMenuButton("층별안내", self.showFloorGuide), 2)
        layout.addWidget(createMenuButton("매장검색", self.showShopContent), 2)
        layout.addWidget(createMenuButton("로봇 길안내", self.showRobotDestination), 2)

        lang_w = QWidget()
        vlang = QVBoxLayout(lang_w)
        vlang.setAlignment(Qt.AlignmentFlag.AlignCenter)
        vlang.addWidget(QLabel("Language", alignment=Qt.AlignmentFlag.AlignCenter))

        hlang = QHBoxLayout()
        ko = QPushButton("가"); en = QPushButton("A")
        for btn in (ko, en):
            btn.setCheckable(True)
            btn.setFixedSize(25, 25)
            btn.setStyleSheet("""
                QPushButton { border: 1px solid #aaa; background-color: #f5fdc; }
                QPushButton:checked { background-color: #ffffff; }
            """)
            hlang.addWidget(btn)
        bg = QButtonGroup(self)
        bg.setExclusive(True)
        bg.addButton(ko); bg.addButton(en)
        ko.setChecked(True)
        vlang.addLayout(hlang)
        layout.addWidget(lang_w)

        layout.addStretch()
        refresh_btn = QPushButton("Home")
        refresh_btn.setStyleSheet("background-color:#f5fdc; border:none; padding:6px 12px; border-radius:8px;")
        refresh_btn.clicked.connect(self.refresh_to_base)
        layout.addWidget(refresh_btn, alignment=Qt.AlignmentFlag.AlignRight)

        return panel

